from flask import Blueprint, request, jsonify

price_check_bp = Blueprint('price_check_bp', __name__)

