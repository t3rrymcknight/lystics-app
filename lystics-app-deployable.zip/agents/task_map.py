fn_map = {
    "Download Image": "downloadImagesToDrive",
    ...
}
